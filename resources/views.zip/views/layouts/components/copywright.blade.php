<div class="copy-right text-center">
    <span><a href="#">DALOCOME</a> &copy; 2023 Developed by RayCom</span>
</div>
