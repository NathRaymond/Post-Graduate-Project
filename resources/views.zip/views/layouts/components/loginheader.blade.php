<div class="d-flex justify-content-between">
    <div class="left-content">
        <ul class="global-list">
            <li><span class="icon"><img src="{{ asset('assets/images/others/icon1.png') }}" alt="Image" class="img-fluid"></span><a href="tel:+234 8146194881">+234 8146194881</a></li>
            <li><span class="icon"><img src="{{ asset('assets/images/others/icon2.png') }}" alt="Image" class="img-fluid"></span><a href="#">rockdalocom@gmail.com</a></li>
        </ul>
    </div><!-- /.left-content -->
    <div class="right-content align-self-center">
        <div class="topbar-user">
            <span><a href="{{ route('login') }}">Login</a> | <a href="{{ route('register') }}">Sign Up</a></span>
        </div><!-- /.topbar-user -->
    </div><!-- /.right-content -->
</div>